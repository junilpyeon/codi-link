package com.rest.api.repo.board;

import com.rest.api.entity.User;
import com.rest.api.entity.board.PostCart;
import com.rest.api.entity.board.Subscribe;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Collection;
import java.util.List;
import java.util.Optional;


public interface SubscribeJpaRepo extends JpaRepository<Subscribe, String> {
	//���� ����Ʈ,���� ���� ����
	@Query("SELECT m FROM Subscribe m WHERE (:uid is null or m.uid = :id) and (:subs_group_id is null or m.subs_group_id = :subs_group_id)")
	List<Subscribe> selectSubscribes(String id, String subs_group_id);
	
	//���� ���� 1�� ��ȸ
	@Query("SELECT m FROM Subscribe m WHERE m.uid = :id and m.subs_uid = :userid")
	Subscribe findByIdAndUserid(@Param("id") String id, @Param("userid") String userid);
	
	//���� ���� 1�� ����
	@Query("DELETE FROM Subscribe m WHERE m.uid = :id and m.subs_uid = :userid")
	Subscribe deleteByIdAndUserid(@Param("id") String id, @Param("userid") String userid);
}