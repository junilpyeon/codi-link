package com.rest.api.repo.board;

import com.rest.api.entity.User;
import com.rest.api.entity.board.Board;
import com.rest.api.entity.board.Post;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface PostJpaRepo extends JpaRepository<Post, Long> {
    
    @Query(value="SELECT m FROM Post m WHERE m.board = :boardId order by m.modified_at desc", nativeQuery=true)
    List<Post> findByBoardOrderByNew(Long boardId, String gubun);
    
    @Query(value="SELECT m, (select count(t) from PostCart t where t.post_id=m.post_id) count FROM Post m WHERE m.board = :boardId order by count desc", nativeQuery=true)
    List<Post> findByBoardOrderByHot(Long boardId, String gubun);
    
    @Query(value="SELECT m, (select count(t) from Subscribe t where t.subs_uid=m.uid) count FROM Post m inner join Subscribe WHERE m.board = :boardId order by count desc", nativeQuery=true)
    List<Post> findByBoardOrderByFollow(Long boardId, String gubun);
}