package com.rest.api.repo.board;

import com.rest.api.entity.board.Board;
import com.rest.api.entity.board.Post;
import com.rest.api.entity.board.PostCart;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Collection;
import java.util.List;
import java.util.Optional;


public interface PostCartJpaRepo extends JpaRepository<PostCart, Long> {
	@Query("SELECT m FROM PostCart m WHERE m.feed_id = :id and m.userid = :userid")
	PostCart findByIdAndUserid(@Param("id") Long id, @Param("userid") String userid);
	
	@Query("SELECT m FROM PostCart m WHERE m.userid = :id and m.groupid = :groupid")
	List<PostCart> selectPostCarts(@Param("id") String id, @Param("groupid") long groupid);
	
}