package com.rest.api.service.board;

import java.util.List;
import javax.transaction.Transactional;
import org.springframework.stereotype.Service;

import com.rest.api.entity.User;
import com.rest.api.entity.board.PostCart;
import com.rest.api.repo.board.PostCartJpaRepo;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class PostCartService {
   private final PostCartJpaRepo PostCartJpaRepo;
   
   public List<PostCart> selectPostCarts(String id, long groupid) {
	   return PostCartJpaRepo.selectPostCarts(id, groupid);
   }

   public List<PostCart> selectPostCarts() {
      return PostCartJpaRepo.findAll();
   }

   public PostCart getPostCart(Long id,String userid) {
      return PostCartJpaRepo.findByIdAndUserid(id, userid);
   }

   public PostCart savePostCart(PostCart PostCart) {
      return PostCartJpaRepo.save(PostCart);
   }

   public void deletePostCart(Long id) {
	   PostCartJpaRepo.deleteById(id);
   }

   @Transactional
   public PostCart updatePostCart(Long id, PostCart PostCart) {
	   PostCart PostCartData = PostCartJpaRepo.findById(id).orElseThrow(IllegalArgumentException::new);
	   PostCartData.update(PostCart.getGroupid(), PostCart.getGroupname());
      return PostCartData;
   }
}
