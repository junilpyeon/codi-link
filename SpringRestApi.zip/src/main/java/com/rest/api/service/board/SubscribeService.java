package com.rest.api.service.board;

import java.util.List;
import javax.transaction.Transactional;
import org.springframework.stereotype.Service;

import com.rest.api.entity.User;
import com.rest.api.entity.board.PostCart;
import com.rest.api.entity.board.Subscribe;
import com.rest.api.repo.board.SubscribeJpaRepo;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class SubscribeService {
   private final SubscribeJpaRepo SubscribeJpaRepo;

   public List<Subscribe> selectSubscribes() {
      return SubscribeJpaRepo.findAll();
   }
   
   public List<Subscribe> selectSubscribes(String id, String subs_group_id) {
	   return SubscribeJpaRepo.selectSubscribes(id, subs_group_id);  
   }

   public Subscribe getSubscribe(String id,String userid) {
      return SubscribeJpaRepo.findByIdAndUserid(id, userid);
   }

   public Subscribe saveSubscribe(Subscribe Subscribe) {
      return SubscribeJpaRepo.save(Subscribe);
   }

   public void deleteSubscribe(String id, String userid) {
	   SubscribeJpaRepo.deleteByIdAndUserid(id, userid);
   }

   @Transactional
   public Subscribe updateSubscribe(String id, String userid, Subscribe Subscribe) {
	   Subscribe SubscribeData = SubscribeJpaRepo.findByIdAndUserid(id, userid);
	   SubscribeData.update(Subscribe.getSubs_group_id(), Subscribe.getSubs_group_name());
      return SubscribeData;
   }
}
