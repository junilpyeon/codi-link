package com.rest.api.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;
import org.springframework.stereotype.Service;

import com.rest.api.entity.User;
import com.rest.api.entity.board.PostCart;
import com.rest.api.entity.board.Subscribe;
import com.rest.api.repo.UserJpaRepo;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class UserService {
   private final UserJpaRepo UserJpaRepo;

   
   public User getUserList(String uid, String gender, String clothes_size) {
	   return UserJpaRepo.findByIdAndList(uid, gender, clothes_size);
   }

   public User getUserInfo(String id, String uid) {
	   if(uid!=null) {
		   id = null;
	   }
	   return UserJpaRepo.findByIdAndInfo(id, uid);
   }


}
