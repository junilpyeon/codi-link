package com.rest.api.entity.board;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.rest.api.entity.User;
import com.rest.api.entity.common.CommonDateEntity;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Proxy;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Getter
@Setter
@NoArgsConstructor
@Table(name = "CL_FEED")
public class Post extends CommonDateEntity implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long feedId;
    @Column(nullable = false, length = 50)
    private String author;
    @Column(nullable = false, length = 100)
    private String title;
    @Column(length = 500)
    private String content;
    @Column(length = 500)
    private String img;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "board_id")
    private Board board; // �Խñ� - �Խ����� ���� - N:1

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "msrl")
    private User user;  // �Խñ� - ȸ���� ���� - N:1

    // Join ���̺��� Json����� ǥ�õ��� �ʵ��� ó��.
    @JsonIgnore
    public Board getBoard() {
        return board;
    }

    // ������
    public Post(User user, Board board, String author, String title, String content, String img) {
        this.user = user;
        this.board = board;
        this.author = author;
        this.title = title;
        this.content = content;
        this.img = img;
    }

    // ������ ������ ó��
    public Post setUpdate(String author, String title, String content, String img) {
        this.author = author;
        this.title = title;
        this.content = content;
        this.img = img;
        return this;
    }
}
