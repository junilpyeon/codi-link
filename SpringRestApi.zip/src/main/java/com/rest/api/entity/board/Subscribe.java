package com.rest.api.entity.board;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.rest.api.entity.User;
import com.rest.api.entity.common.CommonDateEntity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name = "CL_SUBSCRIBE")
public class Subscribe {
   @Id
   @GeneratedValue(strategy=GenerationType.IDENTITY) 
   Long subscribe_seq;
   Long subs_group_id;
   String subs_group_name;
   String uid;
   String subs_uid;

   public void update(Long subs_group_id, String subs_group_name) {
      this.subs_group_id = subs_group_id;
      this.subs_group_name = subs_group_name;
   }
}
