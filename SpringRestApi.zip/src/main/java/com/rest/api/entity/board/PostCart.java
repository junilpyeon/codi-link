package com.rest.api.entity.board;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.rest.api.entity.User;
import com.rest.api.entity.common.CommonDateEntity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name = "CL_POST_CART")
public class PostCart {
   @Id
   @GeneratedValue(strategy=GenerationType.IDENTITY) 
   Long feedlike_id;
   Long feed_id;
   String userid;
   String groupid;
   String groupname;

   public void update(String groupid, String groupname) {
      this.groupid = groupid;
      this.groupname = groupname;
   }
}
