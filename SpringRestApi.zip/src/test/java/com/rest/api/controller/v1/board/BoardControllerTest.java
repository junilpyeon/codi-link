package com.rest.api.controller.v1.board;

public class BoardControllerTest {

}